const times = [
    { nome: 'Freiburg', vitorias: 10, derrotas: 2, gols: 20},
    { nome: 'Wolfsburg', vitorias: 8, derrotas: 4, gols: 18},
    { nome: 'Bayern', vitorias: 12, derrotas: 0 ,gols:23 },
    { nome: 'Bochum', vitorias: 6, derrotas: 6 ,gols: 7},
    { nome: 'Borusia', vitorias: 8, derrotas: 4, gols:12 },
    { nome: 'Mainz 05', vitorias: 11, derrotas: 1 , gols:14 },
    { nome: 'Hoffenheim', vitorias: 3, derrotas: 9 , gols: 4},
    { nome: 'Werder Bremen', vitorias: 9, derrotas: 3, gols:11 },
    { nome: 'Augsburg', vitorias: 1, derrotas: 11, gols: 3},
    { nome: 'St. Pauli', vitorias: 3, derrotas: 9 , gols:8 },
    { nome: 'RB Leipzig', vitorias: 7, derrotas: 5 , gols: 11},
    { nome: 'Leverkusen', vitorias: 4, derrotas: 8 , gols: 5}

];

// Função para somar todos os gols
const somarGols = (arrayTimes) => {
    return arrayTimes.reduce((acumulador, time) => acumulador + time.gols, 0);
};

const totalGols = somarGols(times);
console.log(totalGols); // Exibe a soma total dos gols


        // Função para calcular os pontos (cada vitória vale 3 pontos, derrota 0)
        // Utilizado o metodo spread para expandir o valor das vitorias e contabilizando os pontos.
        const calcularPontos = (...resultados) => {
            let [vitorias, derrotas] = resultados;
            return vitorias * 3;
          };

        // Criar um novo array com os times e seus pontos usando o map()
        const timesComPontos = times.map(time => {
            return { 
                ...time, 
                pontos: calcularPontos(time.vitorias, time.derrotas)
            };
        });

        // Ordenar os times pela pontuação em ordem decrescente usando o sort()
        const timesOrdenados = timesComPontos.sort((a, b) => b.pontos - a.pontos);


        // Filtrar os times com mais de 10 vitórias
        const timesVitorias = times.filter(time => time.vitorias > 10);


        // Função para gerar cada coluna da tabela
        const gerarColuna = (arrayTimes, colunaId, chave) => {
            const tabelaBody = document.querySelector(`#${colunaId} tbody`);
            tabelaBody.innerHTML = ''; // Limpa a tabela antes de adicionar
        
            arrayTimes.forEach(time => {
                const linha = document.createElement('tr');
                linha.innerHTML = `<td>${time[chave]}</td>`;
                tabelaBody.appendChild(linha);
            });
        };
        
        // Adicionar uma linha para o total de gols
        const gerarTotalGols = (totalGols, colunaId) => {
        const tabelaBody = document.querySelector(`#${colunaId} tbody`);
        tabelaBody.innerHTML = ''; // Limpa a tabela antes de adicionar
        const linha = document.createElement('tr');
        linha.innerHTML = `<td>${totalGols}</td>`;
        tabelaBody.appendChild(linha);

    }

        // Função para gerar a tabela com os times filtrados
        const gerarTimesFiltrados = (arrayTimes, colunaId) => {
            const tabelaBody = document.querySelector(`#${colunaId} tbody`);
            tabelaBody.innerHTML = ''; // Limpa a tabela antes de adicionar
        
            arrayTimes.forEach(time => {
                const linha = document.createElement('tr');
                linha.innerHTML = `
                    <td>${time.nome}</td>
                    <td>${calcularPontos(time.vitorias)}</td>
                    <td>${time.vitorias}</td>
                `;
                tabelaBody.appendChild(linha);
            });
        };
        // Exibir as colunas
        gerarColuna(timesOrdenados, 'colunaTimes', 'nome');
        gerarColuna(timesOrdenados, 'colunaPontos', 'pontos');
        gerarColuna(timesOrdenados, 'colunaVitorias', 'vitorias');
        gerarColuna(timesOrdenados, 'colunaDerrotas', 'derrotas');
        gerarColuna(timesOrdenados, 'colunaGols', 'gols');
        gerarTotalGols(totalGols, 'colunaGolTot');
        gerarTimesFiltrados(timesVitorias, 'TimesFiltrados');