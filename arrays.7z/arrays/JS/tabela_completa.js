const times = [
    { nome: 'Freiburg', vitorias: 10, derrotas: 2, gols: 20},
    { nome: 'Wolfsburg', vitorias: 8, derrotas: 4, gols: 18},
    { nome: 'Bayern', vitorias: 12, derrotas: 0 ,gols:23 },
    { nome: 'Bochum', vitorias: 6, derrotas: 6 ,gols: 7},
    { nome: 'Borrusia', vitorias: 8, derrotas: 4, gols:12 },
    { nome: 'Mainz 05', vitorias: 11, derrotas: 1 , gols:14 },
    { nome: 'Hoffenheim', vitorias: 3, derrotas: 9 , gols: 4},
    { nome: 'Werder Bremen', vitorias: 9, derrotas: 3, gols:11 },
    { nome: 'Augsburg', vitorias: 1, derrotas: 11, gols: 3},
    { nome: 'St. Pauli', vitorias: 3, derrotas: 9 , gols:8 },
    { nome: 'RB Leipzig', vitorias: 7, derrotas: 5 , gols: 11},
    { nome: 'Leverkusen', vitorias: 4, derrotas: 8 , gols: 5}

];
        // Função para calcular os pontos (cada vitória vale 3 pontos, derrota 0)
        const calcularPontos = (vitorias, derrotas) => vitorias * 3;

        // Criar um novo array com os times e seus pontos usando o map()
        const timesComPontos = times.map(time => {
            return { 
                ...time, 
                pontos: calcularPontos(time.vitorias, time.derrotas)
            };
        });

        // Ordenar os times pela pontuação em ordem decrescente usando o sort()
        const timesOrdenados = timesComPontos.sort((a, b) => b.pontos - a.pontos);

        // Filtrar os times que têm mais de 5 vitórias usando o filter()
        const timesComMaisDeCincoVitorias = timesOrdenados.filter(time => time.vitorias > 5);

        // Função para gerar as linhas da tabela
        const gerarTabela = (arrayTimes) => {
            const tabelaBody = document.querySelector('#tabelaTimes tbody');
            tabelaBody.innerHTML = ''; // Limpa a tabela antes de adicionar

            arrayTimes.forEach(time => {
                const linha = document.createElement('tr');
                linha.innerHTML = `
                    <td>${time.nome}</td>
                    <td>${time.pontos}</td>
                    <td>${time.vitorias}</td>
                    <td>${time.derrotas}</td>
                    <td>${time.gols}</td>
                `;
                tabelaBody.appendChild(linha);
            });
        };

        // Exibir a tabela inicial
        gerarTabela(timesOrdenados);

        // Exemplo de uso do reduce() - somar todas as vitórias
        const totalVitorias = times.reduce((total, time) => total + time.vitorias, 0);
        console.log(`Total de vitórias de todos os times: ${totalVitorias}`);
